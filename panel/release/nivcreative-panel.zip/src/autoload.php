<?php
declare(strict_types=1);

// Minimal PSR-4 autoloader for the Nivc\ namespace (no Composer needed on shared hosting).
spl_autoload_register(static function (string $class): void {
    $prefix = 'Nivc\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    $file = __DIR__ . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require_once __DIR__ . '/Core/compat.php';
require_once __DIR__ . '/Core/functions.php';
